import 'package:flutter/material.dart';
import 'package:sso_futurescape/config/colors/color.dart';
import 'package:sso_futurescape/ui/module/sso/signup/interest.dart';
import 'package:sso_futurescape/ui/widgets/back_button.dart';

class OtpPage extends StatefulWidget {
  @override
  _OtpPageState createState() => new _OtpPageState();
}

class _OtpPageState extends State<OtpPage> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          leading: FsBackButton(),
        ),
        resizeToAvoidBottomPadding: false,
        body: Container(
          decoration: BoxDecoration(
            image: new DecorationImage(
              image: new ExactAssetImage('images/bg.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Stack(
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                      padding:
                      EdgeInsets.only(top: 35.0, left: 20.0, right: 20.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        mainAxisSize: MainAxisSize.max,
                        children: <Widget>[
                          Container(
                            child: Stack(
                              children: <Widget>[
                                new Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    children: <Widget>[
                                      new Row(
                                        mainAxisAlignment: MainAxisAlignment
                                            .start,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment
                                            .center,
                                        children: <Widget>[
                                          Text(
                                            'we have sent you\nan OTP',
                                            style: TextStyle(
                                                fontFamily: 'Gilroy-Bold',
                                                fontSize: 18.0,
                                                height: 1.5,
                                                letterSpacing: 1.0,
                                                color: FsColor.darkgrey),
                                          ),

                                        ],
                                      ),
                                      SizedBox(height: 10.0),
                                      new Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Flexible(
                                            child: Column(
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              mainAxisSize: MainAxisSize.max,
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                  'enter the 4 digit OTP to proceed - \n******3210',
                                                  style: TextStyle(
                                                      fontFamily: 'Gilroy-Bold',
                                                      fontSize: 13.0,
                                                      height: 1.5,
                                                      color: FsColor.darkgrey
                                                          .withOpacity(0.8)),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ]),
                              ],
                            ),
                          ),
                          Container(
                            child: TextField(
                              obscureText: true,
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                  labelText: 'OTP',
                                  labelStyle: TextStyle(
                                      fontFamily: 'Gilroy-Regular',
                                      color: FsColor.darkgrey),
                                  // hintStyle: ,
                                  focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                      BorderSide(color: FsColor.primary))),
                            ),
                          ),
                          Container(
                            alignment: Alignment.topRight,
                            padding: EdgeInsets.only(
                                top: 15.0, left: 0.0, right: 0.0),
                            child: Text(
                              '0.30s',
                              style: TextStyle(
                                  fontFamily: 'Gilroy-SemiBold',
                                  fontSize: 16.0,
                                  color: FsColor.darkgrey),
                            ),
                          )
                        ],
                      )),
                ],
              ),
              Positioned(
                left: 0.0,
                right: 0.0,
                bottom: 0.0,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      margin: const EdgeInsets.only(bottom: 20.0, left: 20.0),
                      child: GestureDetector(
                        child: FlatButton(
                          padding: EdgeInsets.fromLTRB(30.0, 10.0, 30.0, 10.0),
                          shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.circular(4.0),
                              side: BorderSide(color: FsColor.primary)),
                          child: const Text('Resend OTP',
                              style: TextStyle(fontSize: 16)),
                          color: FsColor.white,
                          textColor: FsColor.primary,
                          onPressed: () {},
                        ),
                      ),
                    ),
                    Padding(padding: EdgeInsets.only(left: 8)),
                    Container(
                      margin: const EdgeInsets.only(bottom: 20.0),
                      child: GestureDetector(
                        child: RaisedButton(
                          padding: EdgeInsets.fromLTRB(30.0, 10.0, 30.0, 10.0),
                          shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(4.0),
                          ),
                          child: const Text('Verify',
                              style: TextStyle(fontSize: 16,
                                fontFamily: 'Gilroy-SemiBold',)),
                          onPressed: () {
                            // _futureloginshowDialog();
                            _otpverifiedshowDialog();
                          },
                          color: FsColor.primary,
                          textColor: FsColor.white,
                        ),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ));
  }

  void _verifyOtp() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => InterestPage()),
    );
  }

  void _otpverifiedshowDialog() {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text("congratulations", textAlign: TextAlign.center,),
          shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(7.0),
          ),
          content: Padding(
            padding: const EdgeInsets.all(0.0),
            child: new Text(
                "your mobile number is verified. \nplease use your mobile number as a username for future login",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Gilroy-Regular',
                    fontSize: 15.0,
                    color: FsColor.darkgrey)),
          ),
          actions: <Widget>[
            // usually buttons at the bottom of the dialog
            FlatButton(
              child: new Text("done",
                style: TextStyle(
                    fontFamily: 'Gilroy-Regular',
                    fontSize: 14.0,
                    color: FsColor.primary),
              ),
              onPressed: () {
                Navigator.of(context, rootNavigator: true).pop();
                _verifyOtp();

                // Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }  


}
