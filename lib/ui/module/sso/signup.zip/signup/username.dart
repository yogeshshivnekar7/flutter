import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:sso_futurescape/config/colors/color.dart';
import 'package:sso_futurescape/presentor/module/sso/login/login_presentor.dart';
import 'package:sso_futurescape/presentor/module/sso/login/login_view.dart';
import 'package:sso_futurescape/ui/module/sso/signup/mobile.dart';
import 'package:sso_futurescape/ui/module/sso/signup/password.dart';
import 'package:sso_futurescape/ui/widgets/mobile_number_widget.dart';

class UsernamePage extends StatefulWidget {
  @override
  _UsernamePageState createState() => new _UsernamePageState();
}

class _UsernamePageState extends State<UsernamePage> implements LoginView {
  ContactNumberController userNameController = new ContactNumberController();

  LoginPresentor _loginPresentor;

  @override
  void initState() {
    _loginPresentor = new LoginPresentor(this);
    super.initState();
    userNameController.addListener(_usernameChange);
  }

  @override
  void dispose() {
    super.dispose();
    userNameController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      resizeToAvoidBottomPadding: false,
      appBar: new AppBar(
        backgroundColor: Colors.transparent,
        leading: Container(),
        elevation: 0.0,
        // leading: Icon(Icons.arrow_back, color: FsColor.darkgrey, size: 18.0),
      ),
      // backgroundColor: FsColor.primary.withOpacity(0.1),
      body: Container(
        decoration: BoxDecoration(
          image: new DecorationImage(
            colorFilter: new ColorFilter.mode(
                Colors.black.withOpacity(0.7), BlendMode.dstATop),
            image: new ExactAssetImage('images/bg.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: <Widget>[
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                    padding: EdgeInsets.fromLTRB(20.0, 35.0, 20.0, 0.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        Container(
                          child: Stack(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.topLeft,
                                padding:
                                    EdgeInsets.fromLTRB(0.0, 30.0, 0.0, 20.0),
                                child: Text(
                                  'enter your\nusername',
                                  style: TextStyle(
                                      fontFamily: 'Gilroy-bold',
                                      letterSpacing: 1.0,
                                      fontSize: 18.0,
                                      height: 1.5,
                                      color: FsColor.darkgrey),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          child: MobileNumberWidget(
                            controller: userNameController,
                            /* decoration: InputDecoration(
                                // labelText: 'Username',
                                hintText: "9999999999",
                                labelStyle: TextStyle(
                                    fontFamily: 'Gilroy-Regular',
                                    color: FsColor.darkgrey),
                                // hintStyle: ,
                                focusedBorder: UnderlineInputBorder(
                                    borderSide:
                                        BorderSide(color: FsColor.primary))),*/
                          ),
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          padding: EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 20.0),
                          child: Text(
                            'dont have a username yet? create with your\nmobile number',
                            style: TextStyle(
                                fontFamily: 'Gilroy-Regular',
                                fontSize: 14.0,
                                color: FsColor.red),
                          ),
                        ),
                      ],
                    )),
              ],
            ),
            Positioned(
              bottom: 0.0,
              left: 0.0,
              right: 0.0,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  !userNameFound
                      ? Container(
                          margin: EdgeInsets.only(bottom: 20.0, left: 20.0),
                          child: GestureDetector(
                            child: RaisedButton(
                              padding:
                                  EdgeInsets.fromLTRB(30.0, 10.0, 30.0, 10.0),
                              shape: new RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(4.0),
                              ),
                              child: Text('Continue',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontFamily: 'Gilroy-SemiBold',
                                  )),
                              onPressed: () {
                                _validateUserName();
                              },
                              color: FsColor.primary,
                              textColor: FsColor.white,
                            ),
                          ),
                        )
                      : Container(),
                  userNameFound
                      ? Container(
                          margin: EdgeInsets.only(bottom: 20.0, left: 20.0),
                          child: GestureDetector(
                            child: RaisedButton(
                              padding:
                                  EdgeInsets.fromLTRB(30.0, 10.0, 30.0, 10.0),
                              shape: new RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(4.0),
                              ),
                              child: Text('Use Password',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontFamily: 'Gilroy-SemiBold',
                                  )),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => PasswordPage(
                                          userNameController.text)),
                                );
                              },
                              color: FsColor.primary,
                              textColor: FsColor.white,
                            ),
                          ),
                        )
                      : Container(),
                  userNameFound && isMobileNumber
                      ? Container(
                          margin: EdgeInsets.only(bottom: 20.0, left: 20.0),
                          child: GestureDetector(
                            child: RaisedButton(
                              padding:
                                  EdgeInsets.fromLTRB(30.0, 10.0, 30.0, 10.0),
                              shape: new RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(4.0),
                              ),
                              child: Text('Use OTP',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontFamily: 'Gilroy-SemiBold',
                                  )),
                              onPressed: () {
                                _validateUserName();
                              },
                              color: FsColor.primary,
                              textColor: FsColor.white,
                            ),
                          ),
                        )
                      : Container()
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool isNumeric(String s) {
    if (s == null) {
      return false;
    }
    return double.parse(s, (e) => null) != null;
  }

  void _validateUserName() {
    if (userNameController.text.trim() != "") {
/*      if (userNameController.country != null) {}*/
      if (isNumeric(userNameController.text)) {
        if (userNameFound) {
        } else {}
      } else if (userNameFound) {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => PasswordPage(userNameController.text)),
        );
      } else {
        _showDialog();
      }
    }
    /* if (userNameController.text == "rahulg") {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => PasswordPage("rahulg")),
      );
    } else if (userNameController.text == "rahuln") {
      _showDialog();
    } else if (userNameController.text == "8149229032") {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => OtpPage()),
      );
    }*/
  }

  void _showDialog() {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text(
            "Your username 'rahuln' not found on SSO",
            textAlign: TextAlign.center,
            style: TextStyle(
                fontFamily: 'Gilroy-Regular',
                fontSize: 14.0,
                color: FsColor.darkgrey),
          ),
          shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(7.0),
          ),
          content: Padding(
            padding: const EdgeInsets.all(0.0),
            child: new Text(
              "Please check your username or create new account",
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontFamily: 'Gilroy-Regular',
                  fontSize: 14.0,
                  color: FsColor.darkgrey),
            ),
          ),
          actions: <Widget>[
            new Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  RaisedButton(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 0.0),
                    shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(4.0),
                    ),
                    child: Text('Change Username',
                        style: TextStyle(
                          fontSize: 13,
                          fontFamily: 'Gilroy-SemiBold',
                        )),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    color: FsColor.primary,
                    textColor: FsColor.white,
                  ),
                  SizedBox(width: 10.0),
                  new FlatButton(
                    child: new Text("Create Account",
                        style: TextStyle(
                          fontSize: 13,
                          fontFamily: 'Gilroy-SemiBold',
                          color: FsColor.darkgrey,
                        )),
                    onPressed: () {
                      Navigator.of(context).pop();
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                MobilePage(MobilePage.NEW_USER, "")),
                      );
                    },
                  ),
                ]),

            // usually buttons at the bottom of the dialog
          ],
        );
      },
    );
  }

  bool userNameFound = false;

  void _usernameChange() {
    if (userNameController.text.length > 3) {
      if (isNumeric(userNameController.text)) {
        _loginPresentor.userCheckUserName(
            userNameController.country.dialingCode + userNameController.text);
      } else {
        _loginPresentor.userCheckUserName(userNameController.text);
      }
    }
    /* if (userNameController.text.trim().isNotEmpty) {
      setState(() {
        print(userNameController.text);
        String dail = "";
        if (userNameController.country == null) {
          dail = userNameController.country.dialingCode;
        }
        if (userNameController.text.trim() == "8149229032") {
          userNameFound = true;
          print(userNameFound);
        } else {
          userNameFound = false;
          print(userNameFound);
        }
      });
    }*/
  }

  @override
  loginError(error) {}

  @override
  loginFailed(String username) {}

  @override
  loginSuccess(data) {}

  @override
  otpError(error) {}

  @override
  otpFailed(String username) {}

  @override
  otpSuccess(data) {}

  @override
  userCheckFailure(error) {
    print("userCheckFailure");
    setState(() {
      userNameFound = false;
      isMobileNumber = false;
    });
  }

  bool isMobileNumber = false;

  @override
  userFound(data) {
    print("userFound");
    setState(() {
      userNameFound = true;
      if (isNumeric(userNameController.text)) {
        isMobileNumber = true;
      }
    });
  }

  @override
  userNameErrror(error) {
    setState(() {
      userNameFound = false;
      isMobileNumber = false;
    });
  }

  @override
  userNameUpdateFailed(var username) {
    print(username);
    print("userNameUpdateFailed");
  }

  @override
  userNameUpdated(data) {
    print("userNameUpdated");
  }

  @override
  userNotFound(String username) {
    print(username);
    print("userNotFound");
  }
}
