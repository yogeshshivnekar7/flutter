import 'package:flutter/material.dart';
import 'package:sso_futurescape/config/colors/color.dart';
import 'package:sso_futurescape/ui/module/sso/signup/username.dart';

class InterestPage extends StatefulWidget {
  @override
  _InterestPageState createState() => new _InterestPageState();
}

class _InterestPageState extends State<InterestPage> {
  var intrestArray = [
    {"name": "tiffin subscription", "isSelected": false},
    {"name": "food ordering", "isSelected": true},
    {"name": "society management", "isSelected": true},
    {"name": "visitor management", "isSelected": false},
  ];

/*  bool isSelected = false;*/

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: AppBar(
          title: Text("select your interest"),
          leading: Container(),

        ),
        resizeToAvoidBottomPadding: false,
        bottomNavigationBar: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              margin: const EdgeInsets.only(bottom: 20.0, left: 20.0),
              child: GestureDetector(
                child: RaisedButton(
                  shape: new RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(4.0),
                  ),
                  child: Text('Done',
                      style: TextStyle(
                          fontSize: 16, fontFamily: 'Gilroy-SemiBold')),
                  onPressed: () {
                    _saveIntrestest(context);
                  },
                  color: FsColor.primary,
                  textColor: FsColor.white,
                ),
              ),
            )
          ],
        ),
        body: Container(
          padding: EdgeInsets.all(4),
          child: ListView.builder(
            /* gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 1,
            ),*/

            itemBuilder: (context, index) {
              return genrateItem(index);
            },
            itemCount: intrestArray.length,
          ),
        ));
  }

  Widget genrateItem(int index) {
    return Column(
      children: <Widget>[
        ListTile(
          title: Text(
            intrestArray[index]["name"].toString(),
            style: TextStyle(
                color: FsColor.darkgrey,
                fontSize: 18.0,
                fontFamily: 'Gilroy-SemiBold'),
          ),
          subtitle: Text(
            intrestArray[index]["name"].toString(),
            style: TextStyle(
              fontFamily: 'Gilroy-Regular',
              color: FsColor.darkgrey,
              fontSize: 14.0,
            ),
          ),
          trailing: Checkbox(
            onChanged: null,
            checkColor: FsColor.primary,
            value: intrestArray[index]["isSelected"],
          ),
          leading:
              // Image(image: NetworkImage("https://anotherjavaduke.files.wordpress.com/2018/08/avataaars-2.png")),
              Container(
            child: Image(
              image: NetworkImage(
                  "https://d3i1chc4akc81x.cloudfront.net/images/default-img.png"),
            ),
          ),
        ),
        Divider(
          thickness: 1,
        )
      ],
    );
  }

  void _saveIntrestest(BuildContext context) {
    // print(intrestArray);
    var selectedList =
        intrestArray.where((item) => item["isSelected"]).toList();
    print(selectedList);

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => UsernamePage()),
    );
  }
}
