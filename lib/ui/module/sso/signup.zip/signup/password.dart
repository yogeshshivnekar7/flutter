import 'package:flutter/material.dart';
import 'package:sso_futurescape/config/colors/color.dart';
import 'package:sso_futurescape/ui/module/sso/reset_password/reset_password.dart';
import 'package:sso_futurescape/ui/module/sso/signup/interest.dart';
import 'package:sso_futurescape/ui/module/sso/signup/mobile.dart';
import 'package:sso_futurescape/ui/widgets/back_button.dart';

class PasswordPage extends StatefulWidget {
  String userName;

  PasswordPage(String password) {
    this.userName = password;
  }

  @override
  _PasswordPageState createState() => new _PasswordPageState(userName);
}

class _PasswordPageState extends State<PasswordPage> {
  String userName;

  _PasswordPageState(String password) {
    this.userName = password;
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        resizeToAvoidBottomPadding: false,
        appBar: new AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          leading: FsBackButton(),
        ),
        body: Container(
          decoration: BoxDecoration(
            image: new DecorationImage(
              image: new ExactAssetImage('images/bg.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Stack(
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                      padding:
                      EdgeInsets.only(top: 35.0, left: 20.0, right: 20.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        mainAxisSize: MainAxisSize.max,
                        children: <Widget>[
                          Container(
                            child: Stack(
                              children: <Widget>[
                                Container(
                                  alignment: Alignment.topLeft,
                                  padding:
                                  EdgeInsets.fromLTRB(0.0, 30.0, 0.0, 20.0),
                                  child: Text(
                                    'enter your\npassword',
                                    style: TextStyle(
                                        fontFamily: 'Gilroy-Bold',
                                        fontSize: 18.0,
                                        height: 1.5,
                                        letterSpacing: 1.0,
                                        color: FsColor.darkgrey),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            child: TextField(
                              obscureText: true,
                              decoration: InputDecoration(
                                  hintText: "Password",
                                  labelStyle: TextStyle(
                                      fontFamily: 'Gilroy-Regular',
                                      color: FsColor.darkgrey),
                                  // hintStyle: ,
                                  focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                      BorderSide(color: FsColor.primary))),
                            ),
                          ),
                          Container(
                            alignment: Alignment.topRight,
                            padding: EdgeInsets.only(
                                top: 0.0, left: 0.0, right: 0.0),
                            child: GestureDetector(
                              child: FlatButton(
                                  key: null,
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              ResetPasswordPage()),
                                    );
                                  },
                                  child: new Text(
                                    "Forgot Password?",
                                    style: new TextStyle(
                                        fontSize: 14.0,
                                        color: FsColor.primary,
                                        fontFamily: "Gilroy-Bold"),
                                  )),
                            ),
                          ),
                        ],
                      )),
                ],
              ),
              Positioned(
                left: 0.0,
                right: 0.0,
                bottom: 0.0,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.only(bottom: 20.0, left: 20.0),
                      child: GestureDetector(
                        child: RaisedButton(
                          padding: EdgeInsets.fromLTRB(30.0, 10.0, 30.0, 10.0),
                          shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(4.0),
                          ),
                          child: const Text('Login',
                              style: TextStyle(
                                fontSize: 16,
                                fontFamily: 'Gilroy-SemiBold',
                              )),
                          onPressed: () {
                            // _loginUsingPassword();
                            if (userName.contains("8149229032")) {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => InterestPage()),
                              );
                            } else {
                              _supportshowDialog();
                            }
                          },
                          color: FsColor.primary,
                          textColor: FsColor.white,
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ));
  }

  BuildContext _loginUsingPassword() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => MobilePage("", "")),
    );

    // context,MaterialPageRoute(builder: (context) => MobilePage(MobilePage.EXISTING,"")),);
  }

  void _supportshowDialog() {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text(
            "alert!",
            textAlign: TextAlign.center,
          ),
          shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(7.0),
          ),
          content: Padding(
            padding: const EdgeInsets.all(0.0),
            child: new Text(
                "we no longer support log in via email/username and password combination. \nplease add your mobile number for login.",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Gilroy-Regular',
                    fontSize: 15.0,
                    color: FsColor.darkgrey)),
          ),
          actions: <Widget>[
            // usually buttons at the bottom of the dialog
            FlatButton(
              child: new Text(
                "add now",
                style: TextStyle(
                    fontFamily: 'Gilroy-SemiBold',
                    fontSize: 14.0,
                    color: FsColor.primary),
                textAlign: TextAlign.center,
              ),
              onPressed: () {
                Navigator.of(context, rootNavigator: true).pop();
                _loginUsingPassword();
                /* if(password=="918149229032"){
                  _loginUsingPassword();
                }else{
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => InterestPage()),
                  );
                }*/
                // Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
