
import 'package:flutter/material.dart';
import 'package:sso_futurescape/config/colors/color.dart';
import 'package:sso_futurescape/ui/module/sso/signup/otp.dart';
import 'package:sso_futurescape/ui/widgets/back_button.dart';

class MobilePage extends StatefulWidget {
  String comingFrom;
  String data;

  static String NEW_USER = "NEW_USERS";

  static String EXISTING = "EXITING";

  MobilePage(String comingFrom, String data) {
    this.comingFrom = comingFrom;
    this.data = data;
  }

  @override
  _MobilePageState createState() => new _MobilePageState(comingFrom, data);
}

class _MobilePageState extends State<MobilePage> {
  String comingFrom;
  String data;

  _MobilePageState(String comingFrom, String data) {
    this.comingFrom = comingFrom;
    this.data = data;
  }

  /* Function ac(){

  }*/
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          leading: FsBackButton(),
        ),
        resizeToAvoidBottomPadding: false,
        body: Container(
          decoration: BoxDecoration(
            image: new DecorationImage(
              image: new ExactAssetImage('images/bg.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Stack(
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                      padding:
                      EdgeInsets.only(top: 35.0, left: 20.0, right: 20.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        mainAxisSize: MainAxisSize.max,
                        children: <Widget>[
                          Container(
                            child: Stack(
                              children: <Widget>[
                                Container(
                                  alignment: Alignment.topLeft,
                                  padding:
                                  EdgeInsets.fromLTRB(0.0, 30.0, 0.0, 20.0),
                                  child: Text(
                                    'give us your\nmobile number',
                                    style: TextStyle(
                                        fontFamily: 'Gilroy-Bold',
                                        letterSpacing: 1.0,
                                        fontSize: 18.0,
                                        height: 1.5,
                                        color: FsColor.darkgrey),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            child: TextField(
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                  hintText: '9999999999',
                                  labelStyle: TextStyle(
                                      fontFamily: 'Gilroy-Regular',
                                      color: FsColor.darkgrey),
                                  // hintStyle: ,
                                  focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                      BorderSide(color: FsColor.primary))),
                            ),
                          ),

                        ],
                      )),
                ],
              ),
              Positioned(
                left: 0.0,
                right: 0.0,
                bottom: 0.0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[


                    new Padding(
                      child:
                      new Checkbox(value: false,
                        onChanged: (newValue) {},
                        activeColor: Colors.transparent,
                        checkColor: FsColor.primary,),
                      padding: const EdgeInsets.all(10.0),
                    ),

                    Row(
                      children: <Widget>[
                        Flexible(
                          child: Column(

                            mainAxisAlignment: MainAxisAlignment.start,
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[

                              new Padding(
                                child: Text(
                                  "I agree to terms & conditions",
                                  style: TextStyle(
                                      fontFamily: 'Gilroy-Regular',
                                      fontSize: 14.0,
                                      color: FsColor.darkgrey.withOpacity(0.8)),
                                ),

                                padding: EdgeInsets.fromLTRB(
                                    20.0, 0.0, 20.0, 0.0),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 20.0,),
                    Container(
                      margin: const EdgeInsets.only(bottom: 20.0, left: 20.0),
                      child: GestureDetector(
                        child: RaisedButton(
                          padding: EdgeInsets.fromLTRB(30.0, 10.0, 30.0, 10.0),
                          shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(4.0),
                          ),
                          child: const Text('Agree & Continue',
                              style: TextStyle(fontSize: 16,
                                fontFamily: 'Gilroy-SemiBold',)),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => OtpPage()),
                            );
                          },
                          color: FsColor.primary,
                          textColor: FsColor.white,
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ));
  }
}




